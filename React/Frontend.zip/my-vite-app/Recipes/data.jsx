export const dish = [
    {
        id: 1,
        name : 'pizza',
        price: 299,
    },
    {
        id: 2,
        name : 'burger',
        price: 199,
    },
    {
        id: 3,
        name : 'pasta',
        price: 249,
    },
    {
        id: 4,
        name : 'salad',
        price: 149,
    },  
    
]