import React from 'react'

const TodoList = () => {
  return (
    <div>
        <h2>Task Planner</h2>
    </div>
  )
}

export default TodoList