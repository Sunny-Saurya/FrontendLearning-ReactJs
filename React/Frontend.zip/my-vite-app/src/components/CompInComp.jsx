import React from 'react'
import Alert from './Alert'

const CompInComp = () => {
  return (
    <div>
        <h3>This is component in component Component</h3>
        <Alert/>
    </div>
  )
}

export default CompInComp