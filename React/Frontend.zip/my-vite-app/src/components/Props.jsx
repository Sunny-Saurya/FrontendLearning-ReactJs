import React from 'react'

const Props = (props) => {
  return (
    <>   
 {/* <div>The brand of the laptop is : {props.brand} and price is : {props.price}</div> */}
    <div>The RAM is : {props.con.RAM} and ROM is : {props.con.ROM}</div>
    {/* <div>The Array's first value is : {props.arr[0]}</div> */}

    </>
  )
}

export default Props