import React from 'react'

const Alert = () => {
  return (
    <div>
        <button onClick={() => alert("welcome to the page")}>Click Me</button>
    </div>
  )
}

export default Alert