import React, { useContext } from 'react';
import ComponentY from './ComponentY';

const ComponentX = () => {
  return (
    <div>
        <ComponentY/>
    </div>
  )
}

export default ComponentX