import React from "react";
import Practice from "./Practice";
class ClassCompInComp extends React.Component{
    render(){
        return <Practice/>
    }
}
export default ClassCompInComp