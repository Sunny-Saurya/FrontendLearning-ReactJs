import React from 'react'
import '../CssComponents/ExternalCss.css'

const ExternalCss = () => {
  return (
    <div className='myStyle'>ExternalCss</div>
  )
}

export default ExternalCss