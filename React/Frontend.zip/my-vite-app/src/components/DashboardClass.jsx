import React from 'react'

class DashboardClass extends React.Component{
    render(){
        return(
            <div>
                <h2>Hey there !! This is Sunny </h2>
            </div>
        )
    }
}

export default DashboardClass