import React from "react"
class Practice extends React.Component{
    render(){
        return React.createElement('h1',{style: {color: "green"}}, 'This is Practice File.' )
    }
}
export default Practice