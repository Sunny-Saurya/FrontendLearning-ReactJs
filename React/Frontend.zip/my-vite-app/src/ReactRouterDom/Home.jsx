import React from 'react'

const Home = () => {
  return (
    <div>
      <br />
      Home Page
    </div>
  );
}

export default Home